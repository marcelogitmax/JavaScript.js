
let variavel = 10 / 10;

console.log(variavel);
