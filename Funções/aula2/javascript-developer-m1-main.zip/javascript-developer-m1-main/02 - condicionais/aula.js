
const numero = 5;
const ehNumeroPar = (numero % 2) === 0;

if (ehNumeroPar) {
    console.log('O número é par');
} else {
    console.log('O número é impar');
}
